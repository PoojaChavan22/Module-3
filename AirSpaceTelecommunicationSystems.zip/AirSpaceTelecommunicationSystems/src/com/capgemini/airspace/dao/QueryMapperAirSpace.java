package com.capgemini.airspace.dao;

public interface QueryMapperAirSpace {

	public static final String INSERT_USER ="INSERT INTO users VALUES(?,?,?,?)";
	
}
