package com.capgemini.airspace.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.airspace.dto.UserBean;
import com.capgemini.airspace.exception.AirSpaceException;
import com.capgemini.airspace.util.DbConnection;

public class AirSpaceDAOImpl implements IAirSapceDAO {

	@Override
	public boolean insertUser(UserBean user) throws AirSpaceException {
		boolean isInserted = false;
		
		try {
			Connection con = DbConnection.getConnection();
			PreparedStatement st = con.prepareStatement(QueryMapperAirSpace.INSERT_USER);
			
			st.setString(1, user.getName());
			st.setString(2, user.getUserName());
			st.setString(3, user.getPassword());
			st.setString(4, user.getMobileNo());
			
			int records = st.executeUpdate();
			
			if(records > 0){
				isInserted = true;
			}
		} catch (SQLException e) {
			throw new AirSpaceException(e.getMessage());
		}
		
		return isInserted;
	}

}
