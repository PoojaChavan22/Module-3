package com.capgemini.airspace.dao;

import com.capgemini.airspace.dto.UserBean;
import com.capgemini.airspace.exception.AirSpaceException;

public interface IAirSapceDAO {
	public boolean insertUser(UserBean user) throws AirSpaceException;
}
