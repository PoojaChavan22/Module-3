package com.capgemini.airspace.service;

import com.capgemini.airspace.dao.AirSpaceDAOImpl;
import com.capgemini.airspace.dao.IAirSapceDAO;
import com.capgemini.airspace.dto.UserBean;
import com.capgemini.airspace.exception.AirSpaceException;

public class AirSpaceServiceImpl implements IAirSpaceService {

	@Override
	public boolean insertUser(UserBean user) throws AirSpaceException {
		IAirSapceDAO airSpaceDAO = new AirSpaceDAOImpl();
		boolean isInserted = airSpaceDAO.insertUser(user);		
		return isInserted;
	}

}
