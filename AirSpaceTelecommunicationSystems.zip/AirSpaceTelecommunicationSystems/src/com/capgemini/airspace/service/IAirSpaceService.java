package com.capgemini.airspace.service;

import com.capgemini.airspace.dto.UserBean;
import com.capgemini.airspace.exception.AirSpaceException;

public interface IAirSpaceService {
	public boolean insertUser(UserBean user) throws AirSpaceException;
}
