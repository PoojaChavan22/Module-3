package com.capgemini.jsp2.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.jsp2.dto.BillDTO;
import com.capgemini.jsp2.dto.ConsumerDTO;
import com.capgemini.jsp2.exception.BillUserException;
import com.capgemini.jsp2.service.EBillServiceImpl;
import com.capgemini.jsp2.service.IEBillService;

/**
 * Servlet implementation class EBillController
 */
@WebServlet({"/EBillController","/Home","/ListConsumer","/SearchConsumer","/BillDetails","/GenerateBill","/SubmitBill","/Search"})
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IEBillService billService = new EBillServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path=request.getServletPath();
		HttpSession session=request.getSession(true);
		String target="";
		
		if(path.equals("/Home"))
		{
			target="pages/home.jsp";
		}
		if(path.equals("/ListConsumer"))
		{
			try {
				List<ConsumerDTO> consumerList=billService.viewAll();
				request.setAttribute("consumers", consumerList);
				target="pages/Show_ConsumerList.jsp";
			} catch (BillUserException e) {
				request.setAttribute("error", e.getMessage());
				target="pages/Error.jsp";
			}
			
		}
		if(path.equals("/SearchConsumer"))
		{
			target="pages/Search_Consumer.jsp";
		}
		if(path.equals("/BillDetails"))
		{
			int consumerId = Integer.parseInt(request.getParameter("num"));
			session.setAttribute("consumerID", consumerId);
			try {
				List<BillDTO> billList = billService.viewBills(consumerId);
				request.setAttribute("bills", billList);
				target="pages/Show_Bills.jsp";
			} catch (BillUserException e) {
				request.setAttribute("error", e.getMessage());
				target="pages/Error.jsp";
			}
			
		}
		if(path.equals("/GenerateBill"))
		{
			target="pages/User_Info.jsp";
		}
		if(path.equals("/SubmitBill"))
		{
			final double FIXED_AMOUNT = 100;
			double netAmount = 0.0;
			double currentReading = Double.parseDouble(request.getParameter("currentReading"));
			double lastReading = Double.parseDouble(request.getParameter("lastReading"));
			
			double unitsConsumed = currentReading - lastReading;
			
			int consumerNo = Integer.parseInt(request.getParameter("consumerNo"));
			
			netAmount = unitsConsumed * 1.15 + FIXED_AMOUNT;
			
			BillDTO billDTO = new BillDTO();
			
			billDTO.setConsumer_num(consumerNo);
			billDTO.setCur_reading(currentReading);
			billDTO.setUnitConsumed(unitsConsumed);
			billDTO.setNetAmount(netAmount);
			request.setAttribute("bill", billDTO);
			
			try {
				String name = billService.insert(billDTO);
				request.setAttribute("name", name);
				target="pages/Bill_Info.jsp";
			} catch (BillUserException e) {
				request.setAttribute("error", e.getMessage());
				target="pages/Error.jsp";
			}
			
		}
		if(path.equals("/Search"))
		{
			int consumerId = Integer.parseInt(request.getParameter("consumerNo"));
			/*request.setAttribute("consumer", consumerId);
			target="pages/Show_Consumer.jsp";*/
			try {
				ConsumerDTO consumer = billService.viewConsumer(consumerId);
				request.setAttribute("consumer", consumer);
				target="pages/Show_Consumer.jsp";
			} catch (BillUserException e) {
				request.setAttribute("error", e.getMessage());
				target="pages/Error.jsp";
			}
		}
		RequestDispatcher disp=request.getRequestDispatcher(target);
		disp.forward(request, response);
	}

}
