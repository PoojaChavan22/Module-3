package com.capgemini.jsp2.exception;

/**
 * Author 		: GUNJAN 
 * Class Name 	: DonorTransactionException 
 * Package 		: com.capgemini.assignment5.exception
 * Date 		: Nov 28, 2017
 */

@SuppressWarnings("serial")
public class BillUserException extends Exception{
	public BillUserException(String message)
	{
		super(message);
	}
}
