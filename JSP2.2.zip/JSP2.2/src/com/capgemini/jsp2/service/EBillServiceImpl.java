package com.capgemini.jsp2.service;

import java.util.List;

import com.capgemini.jsp2.dao.EBillDAOImpl;
import com.capgemini.jsp2.dao.IEBillDAO;
import com.capgemini.jsp2.dto.BillDTO;
import com.capgemini.jsp2.dto.ConsumerDTO;
import com.capgemini.jsp2.exception.BillUserException;

public class EBillServiceImpl implements IEBillService {

	private IEBillDAO ebillDAO;
	
	public EBillServiceImpl() {
		super();
		ebillDAO = new EBillDAOImpl();
	}
	
	@Override
	public String insert(BillDTO billDTO) throws BillUserException {
		boolean isInserted = false;
		String name = null; 
		isInserted = ebillDAO.insertBill(billDTO);
		
		if(isInserted){
			name = ebillDAO.getCustName(billDTO.getConsumer_num());
		}else{
			throw new BillUserException("Record couldn't be inserted");
		}
		return name;
	}

	@Override
	public List<ConsumerDTO> viewAll() throws BillUserException {
		List<ConsumerDTO> consumerList = ebillDAO.viewAll();
		return consumerList;
	}

	@Override
	public ConsumerDTO viewConsumer(int consumerId) throws BillUserException {
		ConsumerDTO consumer = new ConsumerDTO();
		consumer = ebillDAO.viewConsumer(consumerId);
		return consumer;
	}

	@Override
	public List<BillDTO> viewBills(int consumerId) throws BillUserException {
		List<BillDTO> bills = ebillDAO.viewBills(consumerId);
		return bills;
	}

}
