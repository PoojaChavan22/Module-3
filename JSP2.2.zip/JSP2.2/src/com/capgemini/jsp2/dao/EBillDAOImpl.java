package com.capgemini.jsp2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.jsp2.dto.BillDTO;
import com.capgemini.jsp2.dto.ConsumerDTO;
import com.capgemini.jsp2.exception.BillUserException;

public class EBillDAOImpl implements IEBillDAO {

	@Override
	public List<ConsumerDTO> viewAll() throws BillUserException {
		List<ConsumerDTO> consumerList = new ArrayList<ConsumerDTO>();
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			PreparedStatement st = con.prepareStatement(IQueryMapperConsumer.VIEW_ALL);
			ResultSet rs = st.executeQuery();
			
			while(rs.next()){
				ConsumerDTO consumer = new ConsumerDTO();
				consumer.setConsumer_num(rs.getInt(1));
				consumer.setConsumer_name(rs.getString(2));
				consumer.setAddress(rs.getString(3));
				consumerList.add(consumer);
			}
			
			if(consumerList.size()==0){
				throw new BillUserException("No Records Found..");
			}
		} catch (NamingException | SQLException e) {
			throw new BillUserException(e.getMessage());
		}
		return consumerList;
	}

	@Override
	public ConsumerDTO viewConsumer(int consumerId) throws BillUserException {
		ConsumerDTO consumer = new ConsumerDTO();
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			PreparedStatement st = con.prepareStatement(IQueryMapperConsumer.VIEW_CONSUMER);
			st.setInt(1, consumerId);
			ResultSet rs = st.executeQuery();
			if(rs.next()){
				consumer.setConsumer_num(rs.getInt("consumer_num"));
				consumer.setConsumer_name(rs.getString("consumer_name"));
				consumer.setAddress(rs.getString("address"));
			}
			else{
				throw new BillUserException("No record found..");
			}
		} catch (NamingException | SQLException e) {
			throw new BillUserException(e.getMessage());
		}
		return consumer;
	}

	@Override
	public List<BillDTO> viewBills(int consumerId) throws BillUserException {
		List<BillDTO> billList = new ArrayList<BillDTO>();
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			PreparedStatement st = con.prepareStatement(IQueryMapperBillDetails.VIEW_BILLS);
			
			st.setInt(1, consumerId);
			ResultSet rs = st.executeQuery();
			
			while(rs.next()){
				BillDTO bills = new BillDTO();
				bills.setBill_num(rs.getInt(1));
				bills.setCur_reading(rs.getDouble(2));
				bills.setUnitConsumed(rs.getDouble(3));
				bills.setNetAmount(rs.getDouble(4));
				bills.setBill_date(rs.getDate(5));
				bills.setConsumer_num(consumerId);
				
				billList.add(bills);
			}
			
			if(billList.size()==0){
				throw new BillUserException("No Records Found..");
			}
		} catch (NamingException | SQLException e) {
			throw new BillUserException(e.getMessage());
		}
		return billList;
	}

	@Override
	public boolean insertBill(BillDTO bill) throws BillUserException {
		boolean isInserted = false;
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			PreparedStatement st = con.prepareStatement(IQueryMapperBillDetails.INSERT_NEW_BILL);
			
			st.setInt(1, bill.getConsumer_num());
			st.setDouble(2, bill.getCur_reading());
			st.setDouble(3, bill.getUnitConsumed());
			st.setDouble(4, bill.getNetAmount());
			
			int records = st.executeUpdate();
			
			if(records > 0){
				isInserted = true;
			}
		} catch (NamingException | SQLException e) {
			throw new BillUserException(e.getMessage());
		}
		return isInserted;
	}

	@Override
	public String getCustName(int consumerNo) throws BillUserException {
		String custName = null;
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			PreparedStatement st = con.prepareStatement(IQueryMapperConsumer.GET_CONSUMER);
			
			st.setInt(1, consumerNo);
			
			ResultSet rs = st.executeQuery();
			
			if(rs.next()){
				custName = rs.getString(1);
			}
		} catch (NamingException | SQLException e) {
			throw new BillUserException(e.getMessage());
		}
		return custName;
	}
}
