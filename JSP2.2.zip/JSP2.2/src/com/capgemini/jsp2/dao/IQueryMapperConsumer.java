package com.capgemini.jsp2.dao;

public interface IQueryMapperConsumer {
 
	public static final String VIEW_ALL ="SELECT consumer_num,consumer_name,address FROM Consumers";
	
	public static final String VIEW_CONSUMER = "SELECT consumer_num,consumer_name,address FROM Consumers WHERE consumer_num=?";
	
	public static final String GET_CONSUMER = "SELECT consumer_name FROM consumers WHERE consumer_num = ?";
	
	
}
