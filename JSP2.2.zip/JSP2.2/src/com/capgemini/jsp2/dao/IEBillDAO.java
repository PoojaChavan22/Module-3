package com.capgemini.jsp2.dao;

import com.capgemini.jsp2.dto.BillDTO;
import com.capgemini.jsp2.dto.ConsumerDTO;

import java.util.List;

import com.capgemini.jsp2.exception.BillUserException;

public interface IEBillDAO {

	public List<ConsumerDTO> viewAll() throws BillUserException;
	
	public ConsumerDTO viewConsumer(int consumerId) throws BillUserException;
	
	public List<BillDTO> viewBills(int consumerId) throws BillUserException;
	
	public boolean insertBill(BillDTO bill) throws BillUserException;
	
	public String getCustName(int consumerNo) throws BillUserException;
	
}
