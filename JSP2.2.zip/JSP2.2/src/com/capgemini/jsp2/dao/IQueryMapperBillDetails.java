package com.capgemini.jsp2.dao;

public interface IQueryMapperBillDetails {

	public static final String VIEW_BILLS = "SELECT bill_num,cur_reading,unitConsumed,netAmount,bill_date FROM BillDetails WHERE consumer_num=?";
	
	public static final String INSERT_NEW_BILL = "INSERT INTO BillDetails VALUES(seq_bill_num.NEXTVAL,?,?,?,?,SYSDATE)";
}
